import java.awt.*;
import java.awt.event.*;
import java.io.PrintWriter;

import javax.swing.*;


/**
 * @authors Jack Heneghan and Jack Cardwell
 * Computer Science 10: Problem Set 6
 * Client-server graphical editor
 * Dartmouth CS 10, Winter 2015
 */

public class Editor extends JFrame {	
	private static String serverIP = "localhost";			// IP address of sketch server
															// "localhost" for your own machine;
															// or ask a friend for their IP address

	private static final int width = 800, height = 800;		// canvas size

	// GUI components
	private JComponent canvas, gui;
	JDialog colorDialog;
	JColorChooser colorChooser;
	JLabel colorL;

	// Current settings on GUI
	private boolean drawing = true;				// adding objects vs. moving/deleting/recoloring them
	private String shape = "ellipse"; 			// type of object to add
	private Color color = Color.black;			// current drawing color

	// Drawing state
	private Point point = null;					// initial mouse press for drawing; current position for moving
	private Shape current = null;				// the object currently being drawn (if one is)
	private int selected = -1;					// index of object (if any; -1=none) has been selected for deleting/recoloring
	private boolean dragged = false;			// keep track of whether object was actually moved
	
	// The sketch and communication
	private Sketch sketch;						// holds and handles all the drawn objects
	private EditorCommunicator comm;			// communication with the sketch server

	public Editor() {
        super("Graphical Editor");

        sketch = new Sketch();
        
        // Connect to server
        comm = new EditorCommunicator(serverIP, this);
        comm.start();

        // Helpers to create the canvas and GUI (buttons, etc.)
        setupCanvas();
        setupGUI();

        // Put the buttons and canvas together into the window
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(canvas, BorderLayout.CENTER);
        cp.add(gui, BorderLayout.NORTH);

        // Usual initialization
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

	/**
	 * Creates a panel with all the buttons, etc.
	 */
	private void setupGUI() {
		// Toggle whether drawing or editing
		JToggleButton drawingB = new JToggleButton("drawing", drawing);
		drawingB.addActionListener(new AbstractAction("drawing") {
			public void actionPerformed(ActionEvent e) {
				drawing = !drawing;
				current = null;
			}
		});

		// Select type of shape
		String[] shapes = {"ellipse", "rectangle", "segment"};
		JComboBox shapeB = new JComboBox(shapes);
		shapeB.addActionListener(new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				shape = (String)((JComboBox)e.getSource()).getSelectedItem();
			}
		});

		// Select drawing/recoloring color
		// Following Oracle example
		JButton chooseColorB = new JButton("choose color");
		colorChooser = new JColorChooser();
		colorDialog = JColorChooser.createDialog(chooseColorB,
				"Pick a Color",
				true,  //modal
				colorChooser,
				new AbstractAction() { 
			public void actionPerformed(ActionEvent e) {
				color = colorChooser.getColor();
				colorL.setBackground(color); 
			} 
		}, //OK button
		null); //no CANCEL button handler
		chooseColorB.addActionListener(new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				colorDialog.setVisible(true);
			}
		});
		colorL = new JLabel();
		colorL.setBackground(Color.black);
		colorL.setOpaque(true);
		colorL.setBorder(BorderFactory.createLineBorder(Color.black));
		colorL.setPreferredSize(new Dimension(25, 25));

		// Delete object if it is selected
		JButton deleteB = new JButton("delete");
		deleteB.addActionListener(new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				// TODO: YOUR CODE HERE 
				
				//check to make sure that we have an object selected and that it is in the shapeList
				if (selected!=-1){
				
					//request a delete from the server
					comm.requestDelete(sketch.get(selected), selected);
					
					//remove all references to the object
					selected=-1;
					repaint();
				}
			}
		});

		// Recolor object if it is selected
		JButton recolorB = new JButton("recolor");
		recolorB.addActionListener(new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				// TODO: YOUR CODE HERE
				
				//only proceed if there is an object selected
				if(selected!=-1){
					
					//update the color of the object locally
					Shape toRecolor=sketch.get(selected);
					toRecolor.setColor(color);
					
					//request for the color to be updated on the server
					comm.requestRecolor(toRecolor, selected);
				}
			}
		});

		// Put all the stuff into a panel
		gui = new JPanel();
		gui.setLayout(new FlowLayout());
		gui.add(shapeB);
		gui.add(chooseColorB);
		gui.add(colorL);
		gui.add(new JSeparator(SwingConstants.VERTICAL));
		gui.add(drawingB);
		gui.add(deleteB);
		gui.add(recolorB);
	}

	private void setupCanvas() {
		canvas = new JComponent() {
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				// Display the sketch
				// Also display the object currently being drawn in this editor (not yet part of the sketch)
				// TODO: YOUR CODE HERE
				
				//use the draw method of the sketch to draw all of the objects currently in the shapeList
				sketch.drawSketch(g);
				
				//draw the object currently being drawn locally
				if (current != null){
					current.draw(g);
				}
				
				//draw the border on the selected object
				if (selected!=-1 && sketch.get(selected)!=null){
					sketch.get(selected).border(g);
				}
				repaint();
			}
		};
		
		canvas.setPreferredSize(new Dimension(width, height));

		canvas.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent event) {
				point = event.getPoint();
				// In drawing mode, start a new object;
				// in editing mode, set selected according to which object contains the point
				// TODO: YOUR CODE HERE
				
				//in drawing mode, check to see which object type to draw and set current to that object
				if (drawing){
					if (shape.compareTo("ellipse")==0){
						current=new Ellipse(point.x,point.y,event.getX(),event.getY(),color);
					}
					else if (shape.compareTo("rectangle")==0){
						current=new Rectangle(point.x, point.y,event.getX(), event.getY(), color);
					}
					else if(shape.compareTo("segment")==0){
						current=new Segment(point.x,point.y, event.getX(), event.getY(),color);
					}
				}
				
				else if (!dragged){
					
					//use the sketch class' findIndex to find selected
					selected=sketch.findIndex(point.x, point.y);
						
				}
				repaint();
			}

			public void mouseReleased(MouseEvent event) {
				// Pass the update (added object or moved object) on to the server
				// TODO: YOUR CODE HERE
				
				//if the user was drawing send the requestAdd to the server
				if (drawing){
					comm.requestAdd(current);
					current=null;
				}
				
				//otherwise send a request move through the server
				else if (selected!=-1 && dragged) {
					if (sketch.get(selected)!=null){
						comm.requestMove(sketch.get(selected), selected, sketch.get(selected).x1, sketch.get(selected).y1);
					}
					dragged=false;
				}
				
				repaint();
			}
		});		

		canvas.addMouseMotionListener(new MouseAdapter() {
			public void mouseDragged(MouseEvent event) {
				// In drawing mode, update the other corner of the object;
				// in editing mode, move the object by the difference between the current point and the previous one
				// TODO: YOUR CODE HERE
				if (drawing){
					current.setCorners(point.x,point.y,event.getX(),event.getY());
				}
				else if (selected!=-1){
					//get the distance between where the user first clicked and where the user currently has the mouse
					int xDistance=event.getX()-point.x;
					int yDistance=event.getY()-point.y;
					
					sketch.get(selected).moveBy(xDistance, yDistance);
					
					//update the point and the boolean, dragged
					point=event.getPoint();
					dragged=true;
				}
				
				repaint();
			}				
		});
	}

	/**
	 * Getter for the sketch instance variable
	 * @return
	 */
	public Sketch getSketch() {
		return sketch;
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Editor();
			}
		});	
	}
}
